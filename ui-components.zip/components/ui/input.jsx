export function Input(props) {
  return <input className="border p-2 rounded w-full" {...props} />;
}
